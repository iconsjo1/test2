export const tabBarTranslations = {
    home: "Home",
    calendar: "Appointments",
    videocam: "UDH live",
    person: "Reports",
    menu: "Menu",
}

export const homeTabTranslations = {
    header: "United Doctors Hospital",
    menuItem1: "Appointments management",
    menuItem2: "Medical File",
    menuItem3: "Complaints and sugesstions",
    menuItem5: "Book Appointments",
    menuItem4: "Know your doctor",
    menuItem6: "UDH Live",
    news: "News",
    seeMore: "See more",

    unitedTocare: "United To Your Care",
    enterNum: "Enter your phone number and get started with United Doctors Hospital",
    save: "Save and continue",
    doLater: "Do this later",
    num: "Phone number",
    upcoming: "Upcoming appointment",
    centralHospital: ", Central Hospital",
}

export const newsListTranslations = {
    search: "Search ...",
    cacnel: "Cancel",
    seeMore: "See more",
}

export const appointmentTabTranslations = {
    searchSpec: "Search By Speciality",
    searchDoc: "Search By Doctor",
}

export const selectSpecialityTranslations = {
    step: "Step 1 of 3",
    select: "Select Specilaty",
    placeholder: "Search speciality...",
}

export const selectDoctorsTranslations = {
    step: "Step 2 of 3",
    select: "Select Your Doctor",
    placeholder: "Search Doctors",
    noAppointment: "This doctor does not have any appointments for the selected date. Try searching for a next date",
    selectCat: "Select category",
    selectGender: "Select gender",
    NoResults: "No results found against provided information",
    book: "Book"
}

export const bookAppointmentTranslations = {
    step: "Step 3 of 3",
    header: "Book Your Appointment",
    complete: "Complete your information",
    name: "Your name",
    number: "Mobile number",
    scheduled: "Scheduled on",
    selected: "Selected",
    confirm: "Confirm",
    appConfirmed: "Your appointment confirmed",
    please: "Please Try To Be Available Before Your Appointment With 20 Minutes",
    sendLocation: "Send me the hospital location",
    returnMain: "Return to main screen",
    pay: "Do you want to pay for your visit in advance?",
    later: "Later",
    continue: "Continue",
    service: "Service price",
    visit: "visit",
    taxInc: "Tax is included when it's applicable",
    addPromo: "Add Promo",
    payNreq: "Pay & send request",
    enterCode: "Enter promo code",
    cancel: "Cancel",
    apply: "Apply",
    change: "Change",


    udhLive: "UDH Live Services",
    clinicVisits: "Clinic Visits",
    review: "Please review details before proceeding",
    doc: "Doctor",
    name: "Your name",
    num: "Your phone number",
    appDate: "Appointment date",
    appDay: "Appointment day",
    appTime: "Appointment time",
    resType: "Reservation type",
    reg: "Regular",
    udhlive: "UDH Live",

    callText: "We will call you after booking the appointment for confirmation and issuing the invoice. It is important that you answer the call from our number: 012-6533333 to confirm the appointment. \nIn case you missed the call, your appointment will be canceled.",
    close: "Close",
    validNum: "Please enter a valid mobile number",

    shW: "Share on whatsapp",
    shE: "Send in email",
    shC: "Add to calender",
    appMgmt: "Appointments Management",

    details: "Your Appointment Details",
    docName: "DOCTOR NAME:",
    date: "DATE: ",
    time: "TIME: ",
    title: "Doctor Appointment",
    speciality: "Speciality:",
}

export const reportsTabTranslations = {
    insert: "Please, insert you information below:",
    submit: "Submit",
    data1: "Lab Reports",
    data2: "Radiology Reports",
    data3: "Medical Reports",
    data4: "Drugs Description",
    title: "Do you forget your File Number?",
    fileNo: "File No",
    mobileNo: 'Mobile No',
    selectReport: "Please Select the reports you want to see",
    fillForm: "Please Fill the form",
    dataNotFound: "Data not found",
    NoReaports: "No Reports found against the provided information",
    ok: "Ok",
    sortResult: "Sort your Results",
    apply: 'Apply',
    cancel: 'Cancel',
    byDoctor: "By Doctor",
    byService: "By Service",
    byDate: "By Date",
    confirm: "Confirm",
    cancel: "Cancel",
    selectDoctor: "Select Doctor",
    selectService: "Select Service",
    clear: "Clear filters",
}

export const labReportDetails = {
    male: 'Male',
    female: "Female",
    patientName: "Patient Name",
    profileNo: "Profile No",
    gender: "Gender",
    age: "Age",
    basicInfo: 'Basic information',
    resultInfo: "Result Information",
    na: 'N/A',
    result: "Result",
    test: "Test",
    range: "Range",
    from: "From",
    to: "to",
    unit: "Unit",
    downloadNow: "Download Now",
    ok: "Ok",
    docName: "Doctor Name",
    reportDate: "Report Date",
    radiologyReport: "Radiology Report",
    clinicData: "Clinic Data",
    impression: "IMPRESSION",
    title: "Title",
}

export const myAppointments = {
    phone: "Mobile Number",
    showAppointments: "Show My Appointments",
    upcommingAppointments: "Upcoming Appointments",
    passedAppointments: "Passed Appointments",
    todaysAppointments: "Todays Appointments",
    UDHLive: "UDH Live",
    regular: "Regular",
    title: "My Appointments",
    calling: "Wait for calling",
    cancel: "Cancel",
    completed: "Completed",
    confirmationTitle: "Do You Want to cancell appointment?",
    yes: "Yes",
    no: "No"
}

export const menuTabTranslations = {
    myApps: "My Appointments",
    myMessages: "Messages",
    recSession: "Recorded Session",
    ourRooms: "Our Rooms",
    myReports: "My Reports",
    myInvoices: "My Invoices",
    knowYourDoc: "Know Your Doctors",
    reviewOrders: "Review Previous Orders",
    supportTickets: "Support",
    notifications: "Notifications",
    settings: "Settings",
    changeTheme: "Change Theme",
    changeLang: "Change Language",
    aboutH: "About Hospital",
    medSer: "Medical Services",
    hosProced: "Hospital Procedures",
    patiennvisitor: "Patients and Visitors",
    callus: "Call us",
    location: "Location",
    gmMessage: "The General Manager Message",
    changeNum: "Change Your Phone Number",
    close: "Close",
    website: "Visit Our Website",
}

export const udhLiveTabTranslations = {
    comingSoon: "Coming Soon",
}

export const genericTranslations = {
    offline: "You appear to be offline. Check your internet connection and try again",
}