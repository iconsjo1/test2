export const landingTranslations = {
    // imageLine1: "Book an online in-person appointment with a Doctor",
    imageLine1: "يمكنك حجز المواعيد وإلغاء والتعرف على مواعيدك القادمة ",
    // imageLine2: "Check your medical reports, X-ray reports and Pay you invoice",
    imageLine2: "بإمكانك مشاهدة التقارير الطبية ، تقارير الأشعة والمختبر ودفع الفواتير",
    // imageLine3: "Asking doctor a medical query has never been so easy!",
    imageLine3: "سهلنا لك الحصول على الخدمات الصحية بطريقة ذكية وحديثة",
    // imageLine4: "Consult Doctors via Video/Audio and Live chat",
    imageLine4: "يمكنك طلب الاستشارة مع طبيبك أونلاين من خلال خدمة UDH Live",
    // continue: "Continue",
    continue: "التالي",
    // start: "Start",
    start: "البدء الآن",
}