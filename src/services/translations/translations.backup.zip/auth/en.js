export const landingTranslations = {
    imageLine1: "Book an online in-person appointment with a Doctor",
    imageLine2: "Check your medical reports, X-ray reports and Pay you invoice",
    imageLine3: "Asking doctor a medical query has never been so easy!",
    imageLine4: "Consult Doctors via Video/Audio and Live chat",
    continue: "Continue",
    start: "Start",
}