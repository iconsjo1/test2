export const signupSetPassword = {
  setPassword: 'Set Password',
  welcome: 'Welcom',
  welcomeTxt: 'Please set your Password',
  password: 'Password',
  passwordPh: 'Enter your Password',
  PasswordConfirmation: 'Password Confirmation',
  PasswordConfirmationPh: 'Enter your Password Confirmation',
  continue: 'Continue',
  passwordErr: 'Password is Required',
  passwordConfirmationErr: 'Password Confirmation is Required',
  client: 'Client',
};
