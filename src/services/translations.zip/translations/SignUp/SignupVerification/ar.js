export const verificationTranslations = {
  //   verification: 'Verification',
  verification: 'رمز التأكيد',
  //verificationHelpTxt: 'We have sent a four digit verification code to your mobile',
  verificationHelpTxt:
    'لقد قمنا بإرسال رمز تفعيل إلى رقم هاتفك الجوال',
  //   resend: 'Resend',
  resend: 'اعادة إرسال',
  //   verificationErr: 'Code is Required',
  verificationErr: 'من فضلك أدخل كود التفعيل',
  //   verify: 'Verify',
  verify: 'تأكيد',
  //   otp: 'Resend OTP',
  otp: 'إعادة إرسال الرمز',
};
