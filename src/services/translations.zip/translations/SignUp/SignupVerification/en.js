export const verificationTranslations = {
  verification: 'Verification',
  verificationHelpTxt:
    'We have sent a four digit verification code to your mobile',
  resend: 'Resend',
  verificationErr: 'Code is Required',
  verify: 'Verify',
  otp: 'Resend OTP',
};
