export const setPasswordSuccessTranslations = {
  congrats: 'Congrats!',
  helpTxt:
    'You have successfully changed password. Please use the new password when logging in',
  loginNow: 'Login Now',
  goToHome: 'Go to Home',
};
