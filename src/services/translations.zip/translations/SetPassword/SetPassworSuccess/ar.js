export const setPasswordSuccessTranslations = {
  //   congrats: 'Congrats!',
  congrats: 'تهانينا!',
  //helpTxt:'You have successfully changed password. Please use the new password when logging in',
  helpTxt:
    'لقد قمت بتغيير كلمة المرور بنجاح. من فضلك استخدم كلمة المرور الجديدة عند تسجيل الدخول',
  //   loginNow: 'Login Now',
  loginNow: 'تسجيل دخول الآن',
  //   goToHome: 'Go to Home',
  goToHome: 'الذهاب للصفحة الرئيسية',
};
