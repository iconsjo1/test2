export const setPasswordTranslations = {
  setPassword: 'Set Password',
  helpTxt:
    'Reset Code was sent to your mobile number. Please enter the code and enter new password.',
  resetCode: 'Reset Code',
  resetPlaceholder: 'Enter Reset Code',
  password: 'New Password',
  passwordPlaceholder: 'Enter New Password',
  passwordConfrimation: 'New Password Confirmation',
  passwordConfrimationPh: 'Enter Password Confirmation ',
  setPassword: 'Set Password',
  resetCodeErr: 'Rest Code is Required',
  passwordErr: 'Password is Required',
  passwordConfrimationErr: 'Password Confirmation is Required',
};
