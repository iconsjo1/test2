// Additional translations

const commonStrings = {
    // okText: 'Ok',
    okText: 'حسنا',
    // yesText: 'Yes',
    yesText: 'نعم',
    // noText: 'No',
    noText: 'لا',
    // cancelText: 'Cancel',
    cancelText: 'إلغاء',
    // yourProfile: 'Your profile',
    yourProfile: 'ملفك الشخصي',
}
