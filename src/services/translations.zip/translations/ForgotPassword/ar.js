export const forgotPasswordTranslations = {
  //   forgotPassword: 'Forgot Password',
  forgotPassword: 'نسيت كلمة المرور؟',
  //   helpTxt:
  //     'Please enter your mobile number below, to receive your password reset instructions.',
  helpTxt: 'من فضلك أدخل رقم الهوية أدناه لاعادة تهيئة كلمة المرور لحسابك',
  //   udhId: 'ID or Iqama',
  udhId: 'رقم الهوية',
  //   sendCode: 'Send Code',
  sendCode: 'تم إرسال رمز التأكيد',
  //   udhIdErr: 'ID or Iqama is required',
  udhIdErr: 'من فضلك أدخل رقم الهوية ',
};
