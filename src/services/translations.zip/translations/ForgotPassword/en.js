export const forgotPasswordTranslations = {
  forgotPassword: 'Forgot Password',
  helpTxt:
    'Please enter your mobile number below, to receive your password reset instructions.',
  udhId: 'ID or Iqama',
  sendCode: 'Send Code',
  udhIdErr: 'ID or Iqama is required',
};
