export const tabBarTranslations = {
  home: 'Home',
  calendar: 'Appointments',
  videocam: 'UDH live',
  invoice_1: 'Invoices',
  person: 'Reports',
  menu: 'Menu',
};

export const homeTabTranslations = {
  header: 'United Doctors Hospital',
  menuItem1: 'Appointments management',
  menuItem2: 'Medical File',
  menuItem3: 'Complaints and sugesstions',
  menuItem5: 'Book Appointments',
  menuItem4: 'Know your doctor',
  menuItem6: 'UDH Live',
  menuItem7: 'Inpatient Service',
  menuItem8: 'Gifts Shop',
  news: 'News',
  seeMore: 'See more',

  unitedTocare: 'United To Your Care',
  enterNum:
    'Enter your phone number and get started with United Doctors Hospital',
  save: 'Save and continue',
  doLater: 'Do this later',
  num: 'Phone number',
  upcoming: 'Upcoming appointment',
  centralHospital: ', Central Hospital',
  login: 'Login',
  signup: 'Sign Up',
  introTxt:
    'Dear Client, You can access all our services by login in to your medical profile.',
};

export const newsListTranslations = {
  search: 'Search ...',
  cacnel: 'Cancel',
  seeMore: 'See more',
};

export const appointmentTabTranslations = {
  searchSpec: 'Search By Speciality',
  searchDoc: 'Search By Doctor',
};

export const invoiceTabTranslations = {
  paidInvoice: 'Paid',
  unpaidInvoice: 'Unpaid',
  invoices: 'Invoices',
  pay: 'Pay',
  payNow: 'Pay Now',
  invoiceSummary: 'Invoice Summary',
  invoiceNo: 'Invoice NO',
  invoiceDate: 'Invoice Date',
  doctorName: 'Donctor Name',
  Patient: 'Patient',
  ProfileNo: 'Profile No',
  idNo: 'Id No',
  subtotal: 'Subtotal',
  vat: 'VAT',
  total: 'Total',
  paidAmount: 'Paid Amount',
  amountDue: 'Amount Due',
};

export const selectSpecialityTranslations = {
  step: 'Step 1 of 3',
  select: 'Select Specilaty',
  placeholder: 'Search speciality...',
};

export const selectDoctorsTranslations = {
  step: 'Step 2 of 3',
  select: 'Select Your Doctor',
  placeholder: 'Search Doctors',
  noAppointment:
    'This doctor does not have any appointments for the selected date. Try searching for a next date',
  selectCat: 'Select category',
  selectGender: 'Select gender',
  NoResults: 'No results found against provided information',
  book: 'Book',
};

export const bookAppointmentTranslations = {
  step: 'Step 3 of 3',
  header: 'Book Your Appointment',
  complete: 'Complete your information',
  name: 'Your name',
  number: 'Mobile number',
  scheduled: 'Scheduled on',
  selected: 'Selected',
  confirm: 'Confirm',
  appConfirmed: 'Your appointment confirmed',
  please: 'Please Try To Be Available Before Your Appointment With 20 Minutes',
  sendLocation: 'Share Location',
  returnMain: 'Return to main screen',
  pay: 'Do you want to pay for your visit in advance?',
  later: 'Later',
  continue: 'Continue',
  service: 'Service price',
  visit: 'visit',
  taxInc: "Tax is included when it's applicable",
  addPromo: 'Add Promo',
  payNreq: 'Pay & send request',
  enterCode: 'Enter promo code',
  cancel: 'Cancel',
  apply: 'Apply',
  change: 'Change',

  udhLive: 'UDH Live Services',
  clinicVisits: 'Clinic Visits',
  review: 'Please review details before proceeding',
  doc: 'Doctor',
  name: 'Your name',
  num: 'Your phone number',
  appDate: 'Appointment date',
  appDay: 'Appointment day',
  appTime: 'Appointment time',
  resType: 'Reservation type',
  reg: 'Regular',
  udhlive: 'UDH Live',

  callText:
    'We will call you after booking the appointment for confirmation and issuing the invoice. It is important that you answer the call from our number: 012-6533333 to confirm the appointment. \nIn case you missed the call, your appointment will be canceled.',
  close: 'Close',
  validNum: 'Please enter a valid mobile number',

  shW: 'Share on Whatsapp',
  shE: 'Send in Email',
  shC: 'Add to Calender',
  appMgmt: 'Appointments Management',

  details: 'Your Appointment Details',
  docName: 'DOCTOR NAME:',
  date: 'DATE: ',
  time: 'TIME: ',
  title: 'Doctor Appointment',
  speciality: 'Speciality:',
  error: 'An error occurred. Please try again',
  close: 'Close',
  nameError: 'Pleas Enter a valid name',
};

export const reportsTabTranslations = {
  insert: 'Please, insert you information below:',
  submit: 'Submit',
  data1: 'Lab Reports',
  data2: 'Radiology Reports',
  data3: 'Medical Reports',
  data4: 'Drugs Description',
  title: 'Do you forget your File Number?',
  fileNo: 'File No',
  mobileNo: 'Mobile No',
  selectReport: 'Please Select the reports you want to see',
  fillForm: 'Please Fill the form',
  dataNotFound: 'Data not found',
  NoReaports: 'No Reports found against the provided information',
  ok: 'Ok',
  sortResult: 'Sort your Results',
  apply: 'Apply',
  cancel: 'Cancel',
  byDoctor: 'By Doctor',
  byService: 'By Service',
  byDate: 'By Date',
  confirm: 'Confirm',
  cancel: 'Cancel',
  selectDoctor: 'Select Doctor',
  selectService: 'Select Service',
  clear: 'Clear filters',
  mrnNumber: 'MRN Number',
  mrnNumberPlaceholder: 'Enter Your medical record number',
  invoiceNumber: 'Invoice Number',
  invoiceNumberPlaceholder: 'Enter Your Invoice No',
};

export const labReportDetails = {
  male: 'Male',
  female: 'Female',
  patientName: 'Patient Name',
  profileNo: 'Profile No',
  gender: 'Gender',
  age: 'Age',
  basicInfo: 'Basic information',
  resultInfo: 'Result Information',
  na: 'N/A',
  result: 'Result',
  test: 'Test',
  range: 'Range',
  from: 'From',
  to: 'to',
  unit: 'Unit',
  downloadNow: 'Download Now',
  ok: 'Ok',
  docName: 'Doctor Name',
  reportDate: 'Report Date',
  radiologyReport: 'Radiology Report',
  clinicData: 'Clinic Data',
  impression: 'IMPRESSION',
  title: 'Title',
  yourResult: 'Your Result',
  minValue: 'Minimum Value',
  maxValue: 'Maximum Value',
};

export const myAppointments = {
  phone: 'Mobile Number',
  showAppointments: 'Show My Appointments',
  upcommingAppointments: 'Upcoming Appointments',
  passedAppointments: 'Passed Appointments',
  todaysAppointments: 'Todays Appointments',
  UDHLive: 'UDH Live',
  regular: 'Regular',
  title: 'My Appointments',
  calling: 'Wait for calling',
  cancel: 'Cancel',
  completed: 'Completed',
  confirmationTitle: 'Do You Want to cancell appointment?',
  yes: 'Yes',
  no: 'No',
  noApps: 'There are no appointments against this number',
  enterValid: 'Please enter a valid number starts with (05)',
};

export const menuTabTranslations = {
  myApps: 'My Appointments',
  myMessages: 'Messages',
  recSession: 'Recorded Session',
  ourRooms: 'Our Rooms',
  myReports: 'My Reports',
  myInvoices: 'My Invoices',
  knowYourDoc: 'Know Your Doctors',
  reviewOrders: 'Review Previous Orders',
  supportTickets: 'Support',
  notifications: 'Notifications',
  settings: 'Settings',
  changeTheme: 'Change Theme',
  changeLang: 'Change Language',
  aboutH: 'About Hospital',
  medSer: 'Medical Services',
  hosProced: 'Hospital Procedures',
  patiennvisitor: 'Patients and Visitors',
  callus: 'Call us',
  location: 'Location',
  gmMessage: 'The General Manager Message',
  changeNum: 'Change Your Phone Number',
  close: 'Close',
  website: 'Visit Our Website',
  logout: 'Logout',
};

export const udhLiveTabTranslations = {
  comingSoon: 'Coming Soon',
};

export const genericTranslations = {
  offline:
    'You appear to be offline. Check your internet connection and try again',
};

export const paymentTranslations = {
  paymentTitle: 'Payment',
  payAndSendRequest: 'Pay & Send Request',
  servicePrice: 'Service Price',
  taxInclude: "Tax is included when It's applicable",
  addPromoCode: 'Add Promo Code',
  creditCard: 'Credit Card',
  googlePay: 'Google Pay',
  applePay: 'Apple Pay',
};

export const loggedinUser = {
  invoices: 'Invoices',
  book: 'Book Appointments',
  inpatient: 'Inpatient Services',
  labReports: 'Lab Reports',
  radReports: 'Radiology Reports',
  knowYourDoc: 'Know Your Doctor',
  compAndSugg: 'Complaints & Suggestions',
  guide: 'Hospital Guide',
  vital: 'Vital Signs',
};
export const loggedinUserProfile = {
  profile: 'Profile',
  name: 'Patient Name',
  id: 'Id or Iqama',
  mobile: 'Mobile Number',
  gender: 'Gender',
  DOB: 'Date of birth',
  soon: 'Will be implemented',
};

export const inpatientTranslation = {
  inpatient: 'Inpatient Services',
  explaination:
    'In case that you are an inpatient, you can access your services by entering the code delivered to you by the receptionist',
  placeholder: 'Enter your code here',
  access: 'Access Services',
  err: 'Wrong Admission numbers',
};

export const inpatientDetailsTranslation = {
  inpatient: 'Inpatient Services',
  hi: 'Hi',
  adDate: 'Admission Date',
  room: 'Room',
  docName: 'Doctor Name',
  patientRels: 'Patient Relations',
  cleaningSer: 'Clean Service',
  gallery: 'Gallery',
  rate: 'Rate our services',
  flower: 'Gifts shop',
  restaurant: 'Restaurant Service',
};

export const inpatientOrder = {
  patientRels: 'Patient Relations',
  cleaningService: 'Cleaning Service',
  doctorReq: 'Doctor Request',
  maintenance: 'Maintenance',
  dutyManage: 'Duty Manager',
  requestBaby: 'Request Baby',
  pullBaby: 'Pull baby from room',
  orderNo: 'Order Number',
  closingNo: 'Closing Number',
  cancel: 'Cancel',
  sendReminder: 'Send Reminder',
  rate: 'Rate',
  sendReminderMsg:
    'You have sent a new reminder, Pleas Wait 2 minutes, before sending a new one',
  employeeCode: 'Employee Code',
  employeeName: 'Employee Name',
  requestBabyFull: 'Request baby to the room',
  pullBabyFull: 'Pull baby from the room',
};

export const inpatientAlert = {
  continue: 'Continue',
  no: 'No',
  sendReminder: 'Send Remider',
  cleaningHeading: 'Cleaning Service',
  patientRelsHeading: 'Patient Relations',
  subHeadingReminder:
    "Opps! Sorry, You can't send new request While you have an active request would you to send a remider",

  newCleaningSubHeading: `You can use the service to order room cleaning and sanitization, replacement of toiletries, or replacement of towels and bedding, and we can also add an aromatic touch to improve the air quality in the room.`,

  newPatientRelsSubHeading: `Patient Relations can help you communicate with all departments of the hospital tomeet your needs, receive and follow-up complaints and suggestions, or assist you and assist facilities with admission or exit processes. Do not hesitate to contact us...we are just one message away from you`,

  newDoctorReqSubHeading: `In the event that you wish to speak with the attending physician, or have any complications, or wish to check on your health condition or obtain a sick leave. You are in the right place. Your communication is my concern and maintaining your health is my mission in life.`,

  newMaintenanceSubHeading: `In the event of an air conditioning failure, electrical problems, addition or curtains, or in the event of a breakdown in the use of the TV or phone, or any maintenance problems in the bathroom, do not hesitate to contact us to receive a maintenance technician to serve you.`,

  newDutyManagerSubHeading: `I am always here to serve you in case any of the hospital departments is unable to respond to your requests. Contact me and good luck.`,
  newRequestBabySubHeading:
    'Your are about to send request to the nursery to bring your baby to the room are you sure you want to continue?',
  newPullBabySubHeading:
    'Your are about to send request to the nursery to pull your baby from the room are you sure you want to continue?',
  message: 'Write your message here (Optional)',
  rateMsg: 'You can add a review here (Optional)',
  rate: 'Rate our service',
  firstTimeOrderCleaningService: 'You have ordered a Cleaning service',
  reminderMargin: 'You have an active request, Pleas Wait 2 minutes',
  reminderSuccess: 'You have sent a reminder for this service',
  firstTimeOrderPatientRels: 'You have ordered a Patient relations service',
  firstTimeOrderDoctor: 'You have ordered a Doctor service',
  firstTimeOrderMaitenance: 'You have ordered a Maintenace service',
  firstTimeOrderDutyManager: 'You have ordered a Duty Manager service',
  firstTimeOrderRequestBaby:
    'You have ordered a request baby to the room service',
  firstTimeOrderPullBaby: 'You have ordered a Pull Baby from the room service',
};

export const inpatientAlertSuccess = {
  wellDone: 'Well Done!',
  msg:
    'We Recieved your Request you can check all your open Requests from my requests tab',
  myRequest: 'Take me to my requests',
  done: "I'm done for now",
  rateThanks:
    'Thank you, for helping us to be the best version of ourselves, we appreciate your evalution and we will look into it with high considers and care',
  done: 'Done',
};
export const inpatientGallery = {
  gallery: 'Gallery',
  edit: 'Edit',
  delete: 'Delete',
  share: 'Share',
};
export const paymentFailure = {
  header: 'Payment Failure',
  failHeading: 'Your Payment Declined',
  pls: 'Please try again',
  orderNo: 'Order Number',
  price: 'Price',
  sar: 'SAR',
  try: 'Try Again',
};
export const paymentSuccess = {
  header: 'Payment Success',
  failHeading: 'Your Payment Confirmed',
  orderNo: 'Order Number',
  price: 'Price',
  sar: 'SAR',
  try: 'Try Again',
};

export const restaurant = {
  restaurant: 'Restaurant',
  loading: 'Loading Product...',
};

export const vitalReports = {
  noResult: 'No reports found in the selected range. Try select another range',
  noAvaliableData: 'No data Avaiable',
  ranBloodSugar: 'Random Blood Sugar',
  festingBloodSugar: 'Fasting Blood Sugar',
  cholestrol: 'Cholesterol',
  vitaminD: 'Vitamin D',
  triglesrides: 'Triglycerides',
  lastUpdate: 'Last update at',
  loading: 'Loading your reports...',
  normalMinimum: 'Normal Minimum',
  normalMax: 'Normal Max',
  result: 'Results',
};
